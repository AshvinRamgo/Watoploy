#ifndef NEEDLESHALL_H
#define NEEDLESHALL_H

#include "square.h"
#include <memory>
#include <iostream>
#include "player.h"

class Needleshall : public Square {
public:
    Needleshall(int position) : Square(position, "Needleshall") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Needleshall." << std::endl;
    }
};

#endif

