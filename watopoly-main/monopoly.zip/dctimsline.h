#ifndef DCTIMSLINE_H
#define DCTIMSLINE_H

#include "square.h"
#include <memory>
#include <iostream>
#include "player.h"


class Dctimsline : public Square {
public:
    Dctimsline(int position) : Square(position, "Dctimsline") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Dctimsline." << std::endl;
    }
};

#endif

