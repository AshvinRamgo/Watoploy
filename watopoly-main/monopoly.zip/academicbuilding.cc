#include "academicbuilding.h"
#include "player.h"
#include <iostream>

using namespace std;

// AcademicBuilding::AcademicBuilding(int position, const string& name, int price,
//                                    const string& block, int improvementCost)
//     : OwnableSquare(position, name, price),
//       monopolyBlock(block),
//       improvementLevel(0),
//       improvementCost(improvementCost) {}

      AcademicBuilding::AcademicBuilding(int pos, std::string name, std::string block, int cost, int impCost)
      : OwnableSquare(pos, name, cost), monopolyBlock(block), improvementLevel(0), improvementCost(impCost) {}
        
void AcademicBuilding::upgrade() {
    if (improvementLevel < 5) {
        improvementLevel++;
    }
}

void AcademicBuilding::downgrade() {
    if (improvementLevel > 0) {
        improvementLevel--;
    }
}

int AcademicBuilding::getTuition() const {
    // Dynamic tuition calculation based on current price and improvement level
    switch (improvementLevel) {
        case 0: return price / 10;
        case 1: return price / 5;
        case 2: return price / 4;
        case 3: return price / 2;
        case 4: return price;
        case 5: return price * 2;
        default: return price / 10; // Fallback
    }
}

void AcademicBuilding::payTuition(shared_ptr<Player> player) {
    if (owner && owner != player && !mortgaged) {
        int tuition = getTuition();
        player->payRent(tuition, owner);
        cout << player->getName() << " paid $" << tuition << " to " 
             << owner->getName() << " for landing on " << name << "." << endl;
    }
}

int AcademicBuilding::getImprovementLevel() const {
    return improvementLevel;
}

int AcademicBuilding::getImprovementCost() const {
    return improvementCost;
}

string AcademicBuilding::getMonopolyBlock() const {
    return monopolyBlock;
}

void AcademicBuilding::resetImprovements() {
    improvementLevel = 0;
}

void AcademicBuilding::landOn(shared_ptr<Player> player) {
    payTuition(player);
}

