#include "square.h"

Square::Square(int position, std::string name) : 
    position(position), name(name) {}

std::string Square::getName() const {
    return name;
}

int Square::getPosition() const {
    return position;
}
