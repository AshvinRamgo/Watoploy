#ifndef SQUAREFACTORY_H
#define SQUAREFACTORY_H

#include <memory>
#include <string>
#include "square.h"

class SquareFactory {
public:
    static std::shared_ptr<Square> createSquare(int position, const std::string& name);
};

#endif
