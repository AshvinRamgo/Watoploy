#ifndef SQUARE_H
#define SQUARE_H

#include <string>
#include <memory>

class Player;

class Square {
protected:
    int position;
    std::string name;

public:
    Square(int position, std::string name);
    virtual ~Square() = default;

    virtual void landOn(std::shared_ptr<Player> player) = 0;

    std::string getName() const;
    int getPosition() const;
};

#endif
