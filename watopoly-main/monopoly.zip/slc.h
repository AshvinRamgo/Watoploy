#ifndef SLC_H
#define SLC_H

#include "square.h"
#include <memory>
#include <iostream>

class Slc : public Square {
public:
    Slc(int position) : Square(position, "Slc") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Slc." << std::endl;
    }
};

#endif

