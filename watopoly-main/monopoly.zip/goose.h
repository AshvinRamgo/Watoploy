#ifndef GOOSE_H
#define GOOSE_H

#include "square.h"
#include <memory>
#include <iostream>
#include "player.h"


class Goose : public Square {
public:
    Goose(int position) : Square(position, "Goose") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Goose." << std::endl;
    }
};

#endif

