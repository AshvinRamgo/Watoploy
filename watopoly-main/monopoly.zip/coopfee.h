#ifndef COOPFEE_H
#define COOPFEE_H
#include "player.h"
#include "square.h"
#include <memory>
#include <iostream>

class Coopfee : public Square {
public:
    Coopfee(int position) : Square(position, "Coopfee") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Coopfee." << std::endl;
    }
};

#endif

