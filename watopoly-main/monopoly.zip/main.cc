#include <iostream>
#include <memory>
#include "game.h"

int main() {
    // create and run the game
    auto game = std::make_shared<Game>();
    game->runGame();
    
    return 0;
}
