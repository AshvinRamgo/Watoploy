#include "residence.h"
#include <iostream>
#include "player.h"


Residence::Residence(int position, const std::string& name, int price)
    : OwnableSquare(position, name, price) {}

void Residence::landOn(std::shared_ptr<Player> player) {
    std::cout << player->getName() << " landed on a residence." << std::endl;
    // Add logic for rent here
}

