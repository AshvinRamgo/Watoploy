#include "ownablesquare.h"
#include "player.h"

OwnableSquare::OwnableSquare(int position, const std::string& name, int price)
    : Square(position, name), price(price), mortgaged(false) {}

bool OwnableSquare::purchase(std::shared_ptr<Player> player) {
    if (owner || player->getMoney() < price) return false;
    player->updateMoney(-price);
    owner = player;
    return true;
}

void OwnableSquare::mortgage() {
    mortgaged = true;
}

void OwnableSquare::unmortgage() {
    mortgaged = false;
}

std::shared_ptr<Player> OwnableSquare::getOwner() const {
    return owner;
}

bool OwnableSquare::isOwned() const {
    return owner != nullptr;
}

bool OwnableSquare::isMortgaged() const {
    return mortgaged;
}

void OwnableSquare::setOwner(std::shared_ptr<Player> player) {
    owner = player;
}

void OwnableSquare::resetOwnership() {
    owner.reset();
    mortgaged = false;
}

int OwnableSquare::getPurchasePrice() const {
    return price;
}

