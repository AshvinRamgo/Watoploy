#include "textdisplay.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <tuple>
#include <vector>
#include <cstdlib> // For getenv
#include <filesystem>

using namespace std;

// might have to change offset depending -> will know when have all implementaion 

bool isPlayerToken(char ch) {
    return (ch == 'G' || ch == 'B' || ch == 'D' || ch == 'P' ||
            ch == 'S' || ch == '$' || ch == 'L' || ch == 'T');
}

TextDisplay::TextDisplay(Board* board) : board(board) {
    initializeDisplay();
    populateCells();
    drawPlayersOnBoard();
}

void TextDisplay::initializeDisplay() {
    // Try multiple possible locations for board.txt
    string possiblePaths[] = {
        "board.txt",                  // Current directory
        "../board.txt",               // Parent directory
        "watopoly/board.txt",         // watopoly subdirectory
        "../watopoly/board.txt"       // Parent's watopoly subdirectory
    };
    
    ifstream infile;
    bool fileFound = false;
    
    for (const string& path : possiblePaths) {
        infile.open(path);
        if (infile) {
            fileFound = true;
            cout << "Found board.txt at: " << path << endl;
            break;
        }
    }
    
    if (!fileFound) {
        cerr << "Error: Could not find board.txt in any expected location." << endl;
        cerr << "Creating a placeholder board instead." << endl;
        
        // Create a placeholder display
        vector<char> row(80, ' ');
        for (int i = 0; i < 25; i++) {
            theDisplay.push_back(row);
        }
        
        return;
    }
    
    string line;
    theDisplay.clear();
    while(getline(infile, line)) {
        vector<char> row(line.begin(), line.end());
        theDisplay.push_back(row);
    }
    infile.close();
}

void TextDisplay::populateCells() {
    // Mapping: {square index, property name, row, col}
    // These values come from board analysis using the .txt file.
    vector<tuple<int, string, int, int>> mapping = {
        {0,  "COLLECT OSAP", 46, 79},
        {1,  "AL",           0, 11},
        {2,  "SLC",         12,  0},
        {3,  "ML",          49, 50},
        {4,  "TUITION",     47, 47},
        {5,  "MKV",         47, 35},
        {6,  "ECH",         49, 27},
        {7,  "NEEDLES HALL",  0, 13},
        {8,  "PAS",         49, 11},
        {9,  "HH",          49,  2},
        {10, "DC TIMS LINE",48,  0},
        {11, "RCH",         44,  0},
        {12, "PAC",         37,  0},
        {13, "DWE",         34,  0},
        {14, "CPH",         29,  0},
        {15, "UWP",         22,  0},
        {16, "LHI",         19,  0},
        {17, "BMH",          9,  0},
        {18, "OPT",          4,  0},
        {19, "GOOSE NESTING",0,  0},
        {20, "EV1",          0,  3},
        {21, "EV2",          0, 19},
        {22, "EV3",          0, 27},
        {23, "V1",           0,  3},
        {24, "PHYS",         0, 44},
        {25, "B1",           0, 50},
        {26, "CIF",          0, 59},
        {27, "B2",           0, 66},
        {28, "GO TO TIMS",   0, 77},
        {29, "EIT",          4, 75},
        {30, "ESC",          9, 75},
        {31, "C2",          19, 74},
        {32, "REV",         22, 75},
        {33, "MC",          34, 74},
        {34, "COOP FEE",    38, 76},
        {35, "DC",          44, 74}
    };

    for (const auto &entry : mapping) {
        int index;
        string name;
        int row, col;
        tie(index, name, row, col) = entry;
        cells[index] = Cell(row, col);
        cells[index].setPropertyName(name);
    }
}

void TextDisplay::drawPlayersOnBoard() {
    // Clear only previously drawn token positions.
    for (const auto &coord : previousTokenCoords) {
        int r = coord.first;
        int c = coord.second;
        if (r >= 0 && r < static_cast<int>(theDisplay.size()) &&
            c >= 0 && c < static_cast<int>(theDisplay[r].size()))
        {
            if (isPlayerToken(theDisplay[r][c])) {
                theDisplay[r][c] = ' ';
            }
        }
    }
    previousTokenCoords.clear();

    auto players = board->getPlayers();
    for (auto &player : players) {
        int pos = player->getPlayerPosition();
        if (cells.find(pos) == cells.end())
            continue;
        Cell &cell = cells[pos];
        cell.addPlayer(player);
        // Adjust token placement to land within the blank area.
        int baseRow = cell.getRow() + 8;  
        int baseCol = cell.getCol() + 6;  
        auto &playersOnCell = cell.getPlayers();
        int offset = distance(playersOnCell.begin(), 
                              find(playersOnCell.begin(), playersOnCell.end(), player));
        int tokenRow = baseRow + (offset / 3);
        int tokenCol = baseCol + (offset % 3);
        if (tokenRow >= 0 && tokenRow < static_cast<int>(theDisplay.size()) &&
            tokenCol >= 0 && tokenCol < static_cast<int>(theDisplay[tokenRow].size()))
        {
            theDisplay[tokenRow][tokenCol] = player->getNamePieces()[0];
            previousTokenCoords.push_back({tokenRow, tokenCol});
        }
    }
}



void TextDisplay::drawPropertyOwnership() {
    auto squares = board->getSquares();
    
    for (int i = 0; i < static_cast<int>(squares.size()); i++) {
        // Try to cast to OwnableSquare
        auto ownableSquare = dynamic_pointer_cast<OwnableSquare>(squares[i]);
        
        if (ownableSquare && ownableSquare->isOwned()) {
            // Find the cell for this square position
            if (cells.find(i) != cells.end()) {
                Cell& cell = cells[i];
                
                // Get the owner's token (first character of their token string)
                auto owner = ownableSquare->getOwner();
                char ownerToken = owner->getNamePieces()[0];
                
                // Set owner info in the cell (for internal bookkeeping)
                cell.setOwner(ownerToken);
                
                // Choose a safe area in the cell for ownership display.
                // For a 5×8 cell, we use the bottom-right area.
                int ownerRow = cell.getRow() + 4; // Bottom row of the cell
                int ownerCol = cell.getCol() + 6; // Near the right border of the cell
                
                // Boundary check before writing.
                if (ownerRow >= 0 && ownerRow < static_cast<int>(theDisplay.size()) &&
                    ownerCol >= 0 && ownerCol < static_cast<int>(theDisplay[ownerRow].size()))
                {
                    theDisplay[ownerRow][ownerCol] = ownerToken;
                }
                
                // Display mortgage status: show an 'M' to the left of the owner token
                if (ownableSquare->isMortgaged()) {
                    cell.setMortgaged(true);
                    if (ownerCol - 1 >= 0) {
                        theDisplay[ownerRow][ownerCol - 1] = 'M';
                    }
                }
            }
        }
    }
}


// uncomment when accademic building implemented 
void TextDisplay::drawImprovements() {
    // auto squares = board->getSquares();
    // for (int i = 0; i < static_cast<int>(squares.size()); i++) {
    //     // Try to cast to AcademicBuilding to get improvement info.
    //     auto academicBuilding = dynamic_pointer_cast<AcademicBuilding>(squares[i]);
    //     if (academicBuilding) {
    //         int improvements = academicBuilding->getImprovementLevel();
    //         // Only update if there are improvements.
    //         if (cells.find(i) != cells.end() && improvements > 0) {
    //             Cell& cell = cells[i];
    //             cell.setImprovements(improvements);
    //             // Use the bottom row of the cell as the improvement display row.
    //             int impRow = cell.getRow() + 4;  
    //             // Draw up to 8 improvement markers ('I') starting a little inside the cell.
    //             for (int imp = 0; imp < improvements; imp++) {
    //                 if (imp < 8) { // limit to 8 indicators
    //                     int impCol = cell.getCol() + 1 + imp;
    //                     if (impRow < static_cast<int>(theDisplay.size()) &&
    //                         impCol < static_cast<int>(theDisplay[impRow].size()))
    //                     {
    //                         theDisplay[impRow][impCol] = 'I';
    //                     }
    //                 }
    //             }
    //         }
    //     }
    // }
}


void TextDisplay::notify(const Subject* whoNotified) {
    initializeDisplay();
    drawPlayersOnBoard();
    drawPropertyOwnership();
    drawImprovements();
}

void TextDisplay::updateBoard(Cell* cell) {
    // For simplicity, redraw the entire board.
    notify(board);
}

ostream& operator<<(ostream& out, const TextDisplay& td) {
    for (const auto &row : td.theDisplay) {
        for (char ch : row) {
            out << ch;
        }
        out << "\n";
    }
    return out;
}

