#include "gym.h"
#include <iostream>

#include "player.h"


Gym::Gym(int position, const std::string& name, int price)
    : OwnableSquare(position, name, price) {}

void Gym::landOn(std::shared_ptr<Player> player) {
    std::cout << player->getName() << " landed on a gym." << std::endl;
    // Add logic for rent here
}

