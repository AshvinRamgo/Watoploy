#ifndef GOTOTIMS_H
#define GOTOTIMS_H

#include "square.h"
#include <memory>
#include <iostream>
#include "player.h"


class Gototims : public Square {
public:
    Gototims(int position) : Square(position, "Gototims") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Gototims." << std::endl;
    }
};

#endif

