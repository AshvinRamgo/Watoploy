#include "squarefactory.h"
// #include "collectosap.h"
#include "academicbuilding.h"
#include "residence.h"
#include "gym.h"
#include "nonownable.h"

std::shared_ptr<Square> SquareFactory::createSquare(int position, const std::string& name) {
    if (name == "SLC") {
        return std::make_shared<SLC>(position);
    } else if (name == "NEEDLES HALL") {
        return std::make_shared<NeedlesHall>(position);
    } else if (name == "GO TO TIMS") {
        return std::make_shared<GoToTims>(position);
    } else if (name == "DC TIMS LINE") {
        return std::make_shared<DCTimsLine>(position);
    } else if (name == "GOOSE NESTING") {
        return std::make_shared<GooseNesting>(position);
    } else if (name == "TUITION") {
        return std::make_shared<Tuition>(position);
    } else if (name == "COOP FEE") {
        return std::make_shared<CoopFee>(position);
    } else if (name == "COLLECT OSAP") {
        return std::make_shared<CollectOSAP>(position);
    }

    // fallback
    return std::make_shared<AcademicBuilding>(position, name, "UnknownBlock", 0, 0);
}


// std::shared_ptr<Square> SquareFactory::createSquare(int position, const std::string& name) {
//     // if (name == "COLLECT OSAP") {
//     //     return std::make_shared<CollectOSAP>(position);
//     if (name == "SLC") {
//         return std::make_shared<SLC>(position);
//     } else if (name == "NEEDLES HALL") {
//         return std::make_shared<NeedlesHall>(position);
//     } else if (name == "GO TO TIMS") {
//         return std::make_shared<GoToTims>(position);
//     } else if (name == "DC TIMS LINE") {
//         return std::make_shared<DCTimsLine>(position);
//     } else if (name == "GOOSE NESTING") {
//         return std::make_shared<Goose>(position);
//     } else if (name == "TUITION") {
//         return std::make_shared<Tuition>(position);
//     } else if (name == "COOP FEE") {
//         return std::make_shared<CoopFee>(position);
//     }
//     // Add more cases as needed for residences, gyms, and academic buildings

//     // fallback for generic square
//     return std::make_shared<AcademicBuilding>(position, name, "UnknownBlock", 0, 0);
// }
