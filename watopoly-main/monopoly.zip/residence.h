#ifndef RESIDENCE_H
#define RESIDENCE_H

#include "ownablesquare.h"

class Residence : public OwnableSquare {
public:
    Residence(int position, const std::string& name, int price);
    void landOn(std::shared_ptr<Player> player) override;
};

#endif

