#ifndef ACADEMICBUILDING_H
#define ACADEMICBUILDING_H

#include "ownablesquare.h"
#include <string>

class AcademicBuilding : public OwnableSquare {
private:
    std::string monopolyBlock;
    int improvementLevel;
    int improvementCost;

public:
    AcademicBuilding(int position, std::string name, std::string monopolyBlock, int cost, int improvementCost);


    void upgrade();
    void downgrade();
    int getTuition() const;
    void payTuition(std::shared_ptr<Player> player);

    int getImprovementLevel() const;
    int getImprovementCost() const;
    std::string getMonopolyBlock() const;

    void resetImprovements();

    void landOn(std::shared_ptr<Player> player) override;
};

#endif

