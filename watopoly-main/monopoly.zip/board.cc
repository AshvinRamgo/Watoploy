#include "board.h"
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include <unordered_map>
#include "squarefactory.h"
#include "academicbuilding.h"
#include "ownablesquare.h"

using namespace std;

std::string getSquareNameForIndex(int i) {
    static const std::vector<std::string> names = {
        "COLLECT OSAP", "AL", "SLC", "ML", "TUITION", "MKV", "ECH", "NEEDLES HALL", "PAS", "HH",
        "DC TIMS LINE", "RCH", "PAC", "DWE", "CPH", "UWP", "LHI", "SLC", "BMH", "OPT",
        "GOOSE NESTING", "EV1", "NEEDLES HALL", "EV2", "EV3", "V1", "PHYS", "B1", "CIF", "B2",
        "GO TO TIMS", "EIT", "ESC", "SLC", "C2", "REV", "NEEDLES HALL", "MC", "COOP FEE", "DC"
    };

    if (i >= 0 && i < static_cast<int>(names.size())) {
        return names[i];
    } else {
        return "UNKNOWN";
    }
}

Board::Board() : totalCups(0) {
    squares.resize(40);
}

void Board::initBoard() {
    SquareFactory factory;
    for (int i = 0; i < 40; ++i) {
        std::string squareName = getSquareNameForIndex(i);
        squares[i] = factory.createSquare(i, squareName);
    }
}

shared_ptr<Square> Board::getSquare(int index) {
    if (index < 0 || index >= static_cast<int>(squares.size())) {
        throw out_of_range("Square index out of range: " + to_string(index));
    }
    return squares[index];
}

void Board::addPlayer(shared_ptr<Player> player) {
    if (find_if(players.begin(), players.end(), 
                [&player](const shared_ptr<Player>& p) { 
                    return p->getName() == player->getName(); 
                    
                }) == players.end()) {
        players.push_back(player);
        notifyObservers();
    }
}

void Board::removePlayer(shared_ptr<Player> player) {
    auto it = find_if(players.begin(), players.end(), 
                      [&player](const shared_ptr<Player>& p) {
                          return p->getName() == player->getName();
                      });

    if (it != players.end()) {
        players.erase(it);
        notifyObservers();
    }
}

vector<shared_ptr<Player>> Board::getPlayers() const {
    return players;
}

void Board::attach(Observer* observer) {
    Subject::attach(observer);
}

void Board::notifyObservers() const {
    for (auto obs : observers) {
        obs->notify(this);
    }
}


void Board::addCup() {
    if (totalCups >= MAX_CUPS) {
        throw runtime_error("Maximum number of Roll Up the Rim cups already in play");
    }
    totalCups++;
}

void Board::removeCup() {
    if (totalCups <= 0) {
        throw runtime_error("No Roll Up the Rim cups in play");
    }
    totalCups--;
}

int Board::getTotalCups() const {
    return totalCups;
}

bool Board::canAddCup() const {
    return totalCups < MAX_CUPS;
}

const vector<shared_ptr<Square>>& Board::getSquares() const {
    return squares;
}

shared_ptr<Square> Board::findSquareByName(const string& name) {
    auto it = find_if(squares.begin(), squares.end(),
                      [&name](const shared_ptr<Square>& square) {
                          return square->getName() == name;
                      });
    return (it != squares.end()) ? *it : nullptr;
}

vector<shared_ptr<Square>> Board::getMonopolySquares(const string& monopolyBlock) {
    vector<shared_ptr<Square>> result;
    for (auto& square : squares) {
        auto academicBuilding = dynamic_pointer_cast<AcademicBuilding>(square);
        if (academicBuilding && academicBuilding->getMonopolyBlock() == monopolyBlock) {
            result.push_back(square);
        }
    }
    return result;
}

bool Board::ownsMonopoly(shared_ptr<Player> player, const string& monopolyBlock) {
    auto monopolySquares = getMonopolySquares(monopolyBlock);
    for (auto& square : monopolySquares) {
        auto ownableSquare = dynamic_pointer_cast<OwnableSquare>(square);
        if (!ownableSquare || !ownableSquare->isOwned() || 
            ownableSquare->getOwner() != player) {
            return false;
        }
    }
    return !monopolySquares.empty();
}

void Board::saveBoardState(ostream& out) const {
    out << squares.size() << endl;
    for (size_t i = 0; i < squares.size(); i++) {
        auto ownableSquare = dynamic_pointer_cast<OwnableSquare>(squares[i]);
        if (ownableSquare) {
            out << squares[i]->getName() << " ";
            out << (ownableSquare->isOwned() ? ownableSquare->getOwner()->getName() : "BANK") << " ";
            if (ownableSquare->isMortgaged()) {
                out << "-1";
            } else {
                auto academicBuilding = dynamic_pointer_cast<AcademicBuilding>(squares[i]);
                out << (academicBuilding ? academicBuilding->getImprovementLevel() : 0);
            }
            out << endl;
        }
    }
    out << totalCups << endl;
}

void Board::loadBoardState(istream& in) {
    if (squares.empty()) {
        initBoard();
    }

    int numProperties;
    in >> numProperties;

    unordered_map<string, int> propertyIndices;
    for (size_t i = 0; i < squares.size(); i++) {
        propertyIndices[squares[i]->getName()] = static_cast<int>(i);
    }

    for (int i = 0; i < numProperties; i++) {
        string propertyName, ownerName;
        int improvements;
        in >> propertyName >> ownerName >> improvements;

        if (propertyIndices.find(propertyName) != propertyIndices.end()) {
            int index = propertyIndices[propertyName];
            auto ownableSquare = dynamic_pointer_cast<OwnableSquare>(squares[index]);

            if (ownableSquare) {
                if (ownerName != "BANK") {
                    auto playerIt = find_if(players.begin(), players.end(),
                                            [&ownerName](const shared_ptr<Player>& p) {
                                                return p->getName() == ownerName;
                                            });

                    if (playerIt != players.end()) {
                        ownableSquare->setOwner(*playerIt);
                        (*playerIt)->addProperty(ownableSquare);
                    }
                }

                if (improvements == -1) {
                    ownableSquare->mortgage();
                } else {
                    auto academicBuilding = dynamic_pointer_cast<AcademicBuilding>(squares[index]);
                    if (academicBuilding && improvements > 0) {
                        for (int j = 0; j < improvements; j++) {
                            academicBuilding->upgrade();
                        }
                    }
                }
            }
        }
    }

    in >> totalCups;
    notifyObservers();
}

void Board::drawBoard() const {
    notifyObservers();
}
