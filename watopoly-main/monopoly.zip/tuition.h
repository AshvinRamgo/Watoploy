#ifndef TUITION_H
#define TUITION_H
#include "player.h"

#include "square.h"
#include <memory>
#include <iostream>

class Tuition : public Square {
public:
    Tuition(int position) : Square(position, "Tuition") {}
    void landOn(std::shared_ptr<Player> player) override {
        std::cout << player->getName() << " landed on Tuition." << std::endl;
    }
};

#endif

